<!DOCTYPE html>
<html>
<head>
	<title>Latihan2c</title>
		<style>
		.lingkaran {
			width: 50px;
			height: 50px;
			background-color : salmon;
			border: 1px solid black;
			border-radius: 50%;
			float: left;
			line-height: 40px;
			text-align: center;
			margin: 5px;


		}

		.clear{
			clear: both;
		}

	</style>

	<?php 
		$a = "1";
		$b = "2";
		$c = "3";
	?>
	
</head>
<body>

		<!--Baris Pertama-->
		<div class="lingkaran"><?=$a; ?></div>
		<div class="clear"></div>

		<!--Baris Kedua-->
		<div class="lingkaran"><?=$b; ?></div>
		<div class="lingkaran"><?=$b; ?></div>
		<div class="clear"></div>

		<!--Baris Ketiga-->
		<div class="lingkaran"><?=$c ?></div>
		<div class="lingkaran"><?=$c ?></div>
		<div class="lingkaran"><?=$c; ?></div>



</body>
</html>
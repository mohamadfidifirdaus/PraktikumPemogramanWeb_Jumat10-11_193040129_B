<?php

	$i = 1;
	$j = 1;

	while ( $i <= 3) {
		for ($j = 1; $j <= 3 ; $j++) { 
			echo "Ini adalah pengulangan ke-($i,$j)";
			echo "<br>";
		}
		$i++;
	}




?>
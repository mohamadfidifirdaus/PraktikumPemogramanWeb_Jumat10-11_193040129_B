<!DOCTYPE html>
<html>
<head>
	<title>Document</title>
</head>
<body>
	<table border="1" cellspacing="0" cellpadding="10">
		<tr>
			<th></th>
			<?php

				for ($i= 1; $i <= 5 ; $i++): 
			?>

			<th>kolom <?= $i; ?> </th>
		<?php endfor; ?>
		</tr>

		<!--untuk baris pertama-->

		<tr>
			<th>Baris 1</th>

			<?php
				for ($i= 1; $i <= 5 ; $i++): 
			?>

			<th>Baris 1 kolom <?= $i; ?> </th>
		<?php endfor; ?>
		</tr>


		<!--Akhir Dari Baris Pertama -->



		<!--Untuk Baris ke Dua -->

		<tr>
			<th>Baris 2</th>

			<?php
				for ($i= 1; $i <= 5 ; $i++): 
			?>

			<th>Baris 2 kolom <?= $i; ?> </th>
		<?php endfor; ?>
		</tr>

		<!--Akhir Dari Baris ke Dua -->


		<!--Untuk Baris ke Tiga -->

		<tr>
			<th>Baris 3</th>

			<?php
				for ($i= 1; $i <= 5 ; $i++): 
			?>

			<th>Baris 3 kolom <?= $i; ?> </th>
		<?php endfor; ?>
		</tr>

		<!--Akhir Dari Baris ke Tiga -->


		<!--Untuk Baris ke Empat -->

		<tr>
			<th>Baris 4</th>

			<?php
				for ($i= 1; $i <= 5 ; $i++): 
			?>

			<th>Baris 4 kolom <?= $i; ?> </th>
		<?php endfor; ?>
		</tr>

		<!--Akhir Dari Baris ke Empat -->


		<!--Untuk Baris ke Lima -->

		<tr>
			<th>Baris 5</th>

			<?php
				for ($i= 1; $i <= 5 ; $i++): 
			?>

			<th>Baris 5 kolom <?= $i; ?> </th>
		<?php endfor; ?>
		</tr>
		
		<!--Akhir Dari Baris ke Lima -->

	</table>

</body>
</html>
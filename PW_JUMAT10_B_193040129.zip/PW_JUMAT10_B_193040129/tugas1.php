<!DOCTYPE html>
<html>
<head>
	<title>Latihan2c</title>
		<style>
		.lingkaran {
			width: 50px;
			height: 50px;
			background-color : salmon;
			border: 1px solid black;
			border-radius: 50%;
			float: left;
			line-height: 40px;
			text-align: center;
			margin: 5px;


		}

		.clear{
			clear: both;
		}

	</style>

	
</head>
<body>


	<?php

	for ($i = 1; $i <= ; $i++) { 
		# code...
	}




	?>


</body>
</html>